function checkall()  {
	var name= document.getElementById('name').value;
	var email= document.getElementById('email').value;
	var phone= document.getElementById('phone').value;
	var message= document.getElementById('message').value;
	
var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);

	if(name =='') {

	document.getElementById('name').focus();
	return false;
   
	}
	else if(email==''){
		document.getElementById('email').focus();
		return false;
		
	}
	
	else if(phone =='') {
	    document.getElementById('phone');
	    return false;
	}
	
	
	else if(message =='') {
	    document.getElementById('message');
	    return false;
	}

	
	else{
		$('div#connect').html('<img style="height:64px;width:64px;position:absolute;left:50%; margin:-32px 0px 0px -32px; top:50%;" src="images/loader.gif" />');
		$.ajax({
			type:"POST",
			url:"contactpagemail.php",
			data:{name:name,email:email,phone:phone,message:message},
			success: function(info){
			 //$('div#connect').php(info);	
				if(info ==1){
					$('#mailsend1').removeClass('uk-hidden');
					$('#name').val('');
					$('#email').val('');
					$('#phone').val('');
					$('#message').val('');
				}else{
					$('#mailnotsend1').removeClass('uk-hidden');
				}
			}
			
		});
		
	}
	
	}

